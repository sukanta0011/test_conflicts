from .maze_generator import MazeGenerator
